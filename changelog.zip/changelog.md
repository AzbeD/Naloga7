# Zgodovina sprememb
## Spremembe Ažbe
- Dodal sebe kot lastnika kode
- Dodal pravila za obvezen pull request pred združevanjem
- Ustvaril changelog.md datoteko
## Spremembe Anže
- Ustvarjen index.html
- Ustvarjen kontakt.html
- Pull request za vodjo Ažbe
## Spremembe Emil
1. Dodal kontaktne podatke
2. Naredil datoteko z testnimi scenariji

