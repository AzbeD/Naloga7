# Naloga7

## Glavne funkcionalnosti
1. Iskanje avtomobilov
2. Filtriranje avtomobilov
3. Komunikacija s prodajalcem
4. Pošiljanje ponudbe za nakup
5. Registracija in prijava uporabnika